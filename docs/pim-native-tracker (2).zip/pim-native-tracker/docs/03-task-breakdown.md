# 任务拆解

## 阶段一：客户端追踪引擎（核心）

### Task 1.1: NativeTrackerService 框架搭建
- 新建 `Pim.Client.Core/Services/NativeTrackerService.cs`
- 实现 `IHostedService` 接口，随守护程序启停
- 配置读取（`tracker.*` 配置项）
- 日志框架集成（Serilog，按天滚动，30天保留）
- **验收**: 服务能启动/停止，日志文件生成

### Task 1.2: Win32 窗口追踪
- P/Invoke 声明：`GetForegroundWindow`, `GetWindowThreadProcessId`, `QueryFullProcessImageNameW`, `GetWindowTextW`, `GetCommandLineW`
- 窗口信息获取逻辑（管理员权限完整可用）
- UWP ApplicationFrameHost 子窗口解析（`EnumChildWindows`）
- **验收**: 能正确获取前台窗口的 exe 路径、标题和命令行参数

### Task 1.3: Hook + 轮询双引擎
- `SetWinEventHook` 监听 `EVENT_SYSTEM_FOREGROUND` 和 `EVENT_OBJECT_NAMECHANGE`
- Hook 线程消息循环
- 轮询线程（10秒间隔）作为兜底
- Hook 事件和轮询的去重/合并
- Hook 丢失检测和降级（WARN 日志）
- **验收**: 切换窗口时 Hook 立即响应；Hook 丢失时轮询正常工作

### Task 1.4: 空闲检测
- `GetLastInputInfo` + `GetTickCount` 实现
- 空闲阈值判定（默认5分钟）
- 屏幕关闭检测（`GetSystemPowerStatus` / `MonitorPowerControl`）
- 系统睡眠恢复检测（`PowerSettingRegisterNotification`）
- **验收**: 离开电脑5分钟后正确判空闲；屏幕灭立即判空闲

### Task 1.5: 浏览器媒体活跃检测
- 接收 BrowserBridgeService 的心跳数据
- 维护 `browser_audible` 和 `browser_foreground` 状态
- 媒体活跃时延长空闲阈值（×3）
- **验收**: 看YouTube时不判空闲；浏览器不在前台时不影响空闲判定

### Task 1.6: 会话管理状态机
- 会话切分逻辑（AppSwitched / PageVisit / Idle / Gap）
- Grace 期扣除实现
- Gap 检测（轮询间隔×6）
- `__IDLE__` 会话管理
- **验收**: 各种场景下会话切分正确；测试覆盖核心路径

### Task 1.7: 浏览器数据对齐
- 接收浏览器心跳，维护最近心跳缓存
- 窗口事件和浏览器事件的时间戳对齐
- 浏览器 URL 信息合并到 page_visit
- **验收**: Chrome 在前台时，page_visit 带有正确的 URL 和 domain

## 阶段二：浏览器插件

### Task 2.1: Fork aw-watcher-web
- Fork 到 PIM GitHub org
- 改名 `pim-watcher-web`
- 去掉 `aw-client` 依赖，用 fetch 直连
- 修改 manifest.json（名称、描述、权限）
- **验收**: 插件能安装并加载

### Task 2.2: 通信协议实现
- 替换 client.ts，发 HTTP 到 `localhost:15601`
- 实现 ping 端点检测
- 启动时等待 PIM 客户端
- **验收**: 插件能连接 PIM 客户端并发送心跳

### Task 2.3: 简化和清理
- 删除 consent 逻辑
- 删除 hostname 检测
- 删除 settings 页面中的 AW 相关配置
- 简化 storage.ts
- **验收**: 代码干净，无 AW 残留引用

## 阶段三：客户端 HTTP 桥接

### Task 3.1: BrowserBridgeService
- 新建 `Pim.Client.Core/Services/BrowserBridgeService.cs`
- `HttpListener` 监听 `localhost:15601`
- `/browser/heartbeat` 端点接收插件数据
- `/browser/ping` 端点响应连接检测
- 通过 `Channel<T>` 将心跳传递给 NativeTrackerService
- **验收**: 插件能成功 POST 心跳到客户端

### Task 3.2: 上传队列
- 事件批量缓存（最多500条）
- 定时上传（30秒间隔）
- 上传失败重试（最多3次）
- 上传失败计数和错误记录
- **验收**: 数据能批量上传到服务端；网络断开时不丢数据（内存缓存）

## 阶段四：删除 AW 相关代码

### Task 4.1: 删除 AwCollectorService
- 删除 `AwCollectorService.cs`
- 删除 `AwBucketSelection.cs`
- 删除 `AwCollectorCursorState` 相关代码
- 删除客户端中所有 AW 轮询逻辑
- **验收**: 客户端代码中无 AW 引用

### Task 4.2: 服务端清理 AW 接口
- 删除 `/pc/aw/upload-complete` 接口
- 删除 AW 相关的 DTO 和请求模型
- 删除 `pc_aw_events` 表（保留数据迁移到新表后）
- **验收**: 服务端无 AW 相关路由和代码

### Task 4.3: 安装器更新
- 修改 `pim-setup.iss`：移除 `\PIM\PIM KeyStats` 计划任务（KeyStats 改为子进程拉起）
- 保留 `\PIM\PIM Daemon` 计划任务，权限改为 `HIGHEST`
- 清理旧版 KeyStats 计划任务的代码
- **验收**: 安装器只创建一个 HIGHEST 计划任务

## 阶段五：服务端新接口

### Task 5.1: 数据库迁移
- 新建 `pc_tracker_events` 表（含索引）
- EF Core Entity 和 Migration
- **验收**: 迁移脚本执行成功，表结构正确

### Task 5.2: 上传接口
- `POST /pc/tracker/upload` 端点
- 批量插入逻辑
- 认证（复用 daemon token）
- **验收**: 客户端能成功上传事件数据

### Task 5.3: 健康状态接口
- `POST /pc/tracker/health` 端点
- 存储最新健康状态
- **验收**: 能接收并存储客户端健康报告

### Task 5.4: 查询层适配
- 修改 `BrowserPageTimelineBuilder` 支持新数据源
- 修改 `PcActivityAnalysisService` 查询新表
- **验收**: Web 面板数据展示正常

## 阶段六：集成与测试

### Task 6.1: 守护程序集成
- 在 `App.xaml.cs` / `MainShellWindow` 中启动 NativeTrackerService 和 BrowserBridgeService
- 托盘图标状态显示
- 错误通知（气泡提示）
- **验收**: 守护程序启动后追踪器自动运行

### Task 6.2: 日志系统
- 本地日志文件（按天滚动，30天保留）
- 关键日志点覆盖
- 错误 stack trace 记录
- **验收**: 日志文件正确生成，包含所有关键事件

### Task 6.3: 端到端测试
- 守护程序 → 追踪器 → 浏览器插件全链路
- 睡眠/休眠恢复场景
- 长时间运行稳定性（24h+）
- 内存泄漏检测
- **验收**: 全链路数据正确；长时间运行稳定
