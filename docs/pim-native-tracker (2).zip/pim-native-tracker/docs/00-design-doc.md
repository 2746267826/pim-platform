# PIM Native PC Tracker 设计文档

## 1. 目标

去掉 ActivityWatch 依赖，用 Win32 API 实现原生的前台窗口追踪 + 空闲检测，同时 fork aw-watcher-web 浏览器插件直接与 PIM 客户端通信，保留浏览器 URL 级别的使用记录。

### 1.1 交付物

| 组件 | 位置 | 说明 |
|---|---|---|
| NativeTrackerService | `Pim.Client.Core/Services/` | 追踪引擎，随守护程序运行 |
| BrowserBridgeService | `Pim.Client.Core/Services/` | 接收浏览器插件心跳 |
| 浏览器插件 | 独立仓库 `pim-watcher-web` | Fork aw-watcher-web，改 endpoint 指向 PIM 客户端 |
| 服务端新接口 | `Pim.Api` / `Pim.Module.PcTracker` | 新上传接口 + 数据表 + 处理层 |

### 1.2 不做什么

- 不做独立安装器/独立计划任务——追踪器随 PIM 守护程序一起运行
- 不做系统级音频检测——只依赖浏览器插件的 `audible` 字段
- 不做后台播放检测——只关注前台应用
- **不保留 AwCollectorService——完全删除 AW 相关代码**

---

## 2. 架构

### 2.1 数据流

```
┌─────────────────────────────────────────────────────────┐
│  PIM 守护程序 (Pim.Client.App.exe, Task Scheduler HIGHEST) │
│                                                           │
│  ┌───────────────────┐  ┌──────────────────────┐         │
│  │ NativeTrackerService│  │ BrowserBridgeService │         │
│  │ (Win32 API)        │  │ (localhost:15601)    │         │
│  └───────┬───────────┘  └──────────┬───────────┘         │
│          │                         │                      │
│          └────────┬────────────────┘                      │
│                   ▼                                       │
│          ┌────────────────┐                               │
│          │ 事件合并 & 会话 │                               │
│          │ 管理器          │                               │
│          └────────┬───────┘                               │
│                   ▼                                       │
│          ┌────────────────┐                               │
│          │ 上传队列       │─── HTTP ──▶ PIM 服务端         │
│          └────────────────┘                               │
│                                                           │
│  ┌────────────────────────────────────┐                   │
│  │ KeyStats.exe (子进程, 继承HIGHEST)  │                   │
│  │ 独立运行，独立上传键鼠统计数据       │                   │
│  └────────────────────────────────────┘                   │
└───────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────┐
│  浏览器 (Chrome/Edge/Firefox)                    │
│  ┌──────────────────┐                            │
│  │ pim-watcher-web  │──── HTTP POST ──────────▶ │
│  │ (改版aw插件)      │     localhost:15601       │
│  └──────────────────┘                            │
└─────────────────────────────────────────────────┘
```

### 2.2 进程模型

```
Pim.Client.App.exe (守护程序, Task Scheduler HIGHEST, 管理员权限)
│
├── NativeTrackerService (同进程, IHostedService)
│   ├── Hook 线程 (SetWinEventHook, 独立消息循环)
│   ├── 轮询线程 (10秒间隔)
│   └── 上传线程 (30秒批量上传)
│
├── BrowserBridgeService (同进程, HttpListener localhost:15601)
│
├── DaemonHeartbeatReporter (同进程)
│
└── 启动子进程:
    └── KeyStats.exe (继承父进程 HIGHEST 权限)

已删除:
  ✗ AwCollectorService
  ✗ AW 相关所有代码和配置
```

### 2.3 权限模型

```
Task Scheduler:  \PIM\PIM Daemon → HIGHEST (唯一计划任务)

主程序 HIGHEST →
  ├── NativeTrackerService 自动获得管理员权限
  │   ├── GetForegroundWindow / GetWindowThreadProcessId     ✓
  │   ├── QueryFullProcessImageNameW                         ✓
  │   ├── GetWindowTextW                                     ✓
  │   ├── GetCommandLineW (完整命令行参数)                    ✓
  │   ├── GetLastInputInfo (空闲检测)                        ✓
  │   ├── SetWinEventHook (窗口事件监听)                     ✓
  │   └── EnumChildWindows (UWP子窗口解析)                   ✓
  │
  ├── BrowserBridgeService 监听 localhost                    ✓
  │
  └── KeyStats.exe 子进程继承 HIGHEST                        ✓
```

### 2.4 与现有守护程序的关系

```
Pim.Client.App (守护程序进程)
├── [已删除] AwCollectorService
├── [新增] NativeTrackerService
├── [新增] BrowserBridgeService
├── ApiClient               ← 现有
├── DaemonHeartbeatReporter ← 现有
└── 其他现有服务...
```

---

## 3. 算法设计

### 3.1 窗口追踪

#### 检测方式：Hook + 轮询双保险

**Hook 线程**（实时响应）：
```csharp
// 监听前台窗口变化和标题变化
SetWinEventHook(EVENT_SYSTEM_FOREGROUND, ...)
SetWinEventHook(EVENT_OBJECT_NAMECHANGE, ...)
// 收到事件时通过 channel 通知主线程
```

**轮询线程**（兜底，10秒间隔）：
```csharp
// 每10秒检查一次前台窗口
// 如果两次轮询间有 Hook 事件触发，跳过本次轮询（避免重复处理）
```

#### 窗口信息获取（管理员权限）

```csharp
// 1. 获取前台窗口句柄
HWND hwnd = GetForegroundWindow();

// 2. 获取进程ID
uint pid;
GetWindowThreadProcessId(hwnd, &pid);

// 3. 获取进程exe路径
string exePath = QueryFullProcessImageNameW(pid);

// 4. 获取窗口标题
string title = GetWindowTextW(hwnd);

// 5. 获取命令行参数（管理员权限完整可用）
string commandLine = GetCommandLineW(pid);

// 6. UWP特殊处理：检测 ApplicationFrameHost，遍历子窗口找真实进程
if (exePath is "ApplicationFrameHost" or "ShellExperienceHost")
{
    uint childPid = ResolveChildPid(hwnd, pid);
    exePath = QueryFullProcessImageNameW(childPid);
    commandLine = GetCommandLineW(childPid);  // 也拿子进程的命令行
}
```

#### 窗口切换判定

```
if (exe_path 变化):
    → AppSwitched 事件（关旧会话，开新会话）
else if (window_title 变化):
    → PageVisit 事件（同会话内记录页面访问）
else:
    → 无变化
```

### 3.2 空闲检测

#### 基础检测

```csharp
// Win32 API
LASTINPUTINFO info;
GetLastInputInfo(&info);
uint idleMs = GetTickCount() - info.dwTime;
TimeSpan idleDuration = TimeSpan.FromMilliseconds(idleMs);
```

#### 多信号融合判定

```
输入信号：
  idle_duration    : 键鼠无输入时长（Win32 API）
  browser_audible  : 浏览器是否在播放音频（插件心跳提供）
  browser_fg       : 浏览器是否在前台（窗口追踪提供）
  screen_off       : 屏幕是否关闭（GetSystemPowerStatus / MonitorFromWindow）
  system_sleep     : 系统是否从睡眠恢复（PowerSettingRegisterNotification）

判定规则：
  ┌─ 屏幕灭 或 系统睡眠 → 立即判定空闲（强信号）
  │
  ├─ idle_duration > 5分钟：
  │   ├─ 浏览器前台 + audible=true → 活跃（算浏览器时间）
  │   ├─ 浏览器前台 + audible=false → 空闲
  │   └─ 非浏览器前台 → 空闲
  │
  └─ idle_duration ≤ 5分钟 → 活跃
```

#### 空闲 Grace 期

```
场景：10:00 最后操作 Chrome，10:05 系统判定空闲

处理：
  - Chrome 会话结束时间 = 10:00（不是10:05）
  - 空闲会话开始时间 = 10:00
  - grace 时间（5分钟）从 Chrome 会话中扣除

效果：不虚增最后一个应用的使用时长
```

### 3.3 睡眠/休眠 Gap 处理

```csharp
// 检测：两次轮询间隔 > 60秒（轮询间隔×6）
if ((now - lastPollTime) > TimeSpan.FromSeconds(60))
{
    // Gap 发生
    var gapStart = lastPollTime;
    // 在 gap 起点关闭当前会话
    CloseCurrentSession(gapStart);
    // 不创建 __IDLE__ 会话（gap时间不算任何人的时间）
    // 恢复后正常开始新会话
}
```

### 3.4 会话管理

#### 事件类型

```csharp
enum TrackerEvent
{
    AppSwitched,      // 前台exe变化
    PageVisit,        // 同exe内标题变化
    IdleStarted,      // 空闲开始
    IdleEnded,        // 空闲结束
    GapDetected,      // 睡眠/休眠恢复
    BrowserHeartbeat  // 浏览器插件心跳
}
```

#### 会话切分规则

| 事件 | 动作 |
|---|---|
| AppSwitched（exe 变化） | 关闭当前会话，开新会话 |
| PageVisit（同 exe 标题变化） | 不拆会话，记录 page_visit |
| IdleStarted | 关闭当前会话，开 `__IDLE__` 会话 |
| IdleEnded | 关闭 `__IDLE__` 会话，开新会话 |
| GapDetected | 在 gap 起点关闭当前会话 |
| BrowserHeartbeat（audible=true） | 重置空闲计时器（延长空闲阈值） |

#### 会话数据结构

```csharp
class Session
{
    long Id;
    string DeviceId;
    string ExePath;           // "C:\Program Files\Google\Chrome\Application\chrome.exe"
    string AppName;           // "chrome"（标准化后）
    string? WindowTitle;      // 当前窗口标题
    DateTimeOffset StartedAt;
    DateTimeOffset? EndedAt;
    double? DurationSecs;
    bool IsIdle;              // 是否为 __IDLE__ 会话
    bool IsMediaActive;       // 空闲期间是否有媒体播放
    LocalDate Date;
    List<PageVisit> PageVisits;  // 会话内的页面访问记录
}

class PageVisit
{
    long Id;
    long SessionId;
    string? WindowTitle;
    string? Url;              // 来自浏览器插件
    string? Domain;           // 来自浏览器插件
    DateTimeOffset StartedAt;
    DateTimeOffset? EndedAt;
    double? DurationSecs;
}
```

### 3.5 浏览器数据对齐

#### 数据来源

浏览器插件（pim-watcher-web）通过 HTTP POST 发送心跳到 PIM 客户端：

```
POST http://localhost:15601/browser/heartbeat
Content-Type: application/json

{
    "url": "https://github.com/ActivityWatch/aw-watcher-web",
    "title": "aw-watcher-web - GitHub",
    "audible": false,
    "incognito": false,
    "tabCount": 5,
    "timestamp": "2026-08-31T10:05:00Z"
}
```

#### 时间对齐算法

```
输入：
  window_events:  [W1(10:00-10:30, chrome.exe), W2(10:30-11:00, code.exe), ...]
  browser_events: [B1(10:05, github.com), B2(10:15, youtube.com), ...]

合并逻辑：
  1. 找到 browser_event 时间点落在哪个 window_event 内
  2. 如果 window_event 是浏览器进程 → 关联
  3. 在 window_event 内按 browser_event 切分 page_visit

输出：
  W1: chrome.exe (10:00-10:30)
    ├ page_visit: 10:00-10:05, 无URL（地址栏/新标签页）
    ├ page_visit: 10:05-10:15, github.com
    ├ page_visit: 10:15-10:25, youtube.com (audible=true)
    └ page_visit: 10:25-10:30, github.com
```

---

## 4. 浏览器插件改造

### 4.1 Fork 来源

Fork `ActivityWatch/aw-watcher-web`（MPL-2.0 协议，允许修改和分发）。

### 4.2 改动点

| 文件 | 改动 | 说明 |
|---|---|---|
| `src/background/client.ts` | 替换 AWClient 为 fetch 直连 | 去掉 aw-client 依赖 |
| `src/background/client.ts` | baseURL 改为 `http://localhost:15601` | PIM 客户端端口 |
| `src/background/client.ts` | API 格式简化 | 只保留 heartbeat 端点 |
| `src/config.ts` | 端口号 | 15601 |
| `src/manifest.json` | 扩展名称/描述 | "PIM Browser Watcher" |
| `src/background/main.ts` | 去掉 consent/hostname 检测 | 不需要 AW server 连接 |
| `src/storage.ts` | 简化 | 去掉 apiKey/hostname/syncStatus |

### 4.3 通信协议

插件 → PIM 客户端（单向，插件不接收响应）：

```
POST /browser/heartbeat
{
    "url": string,        // 当前标签页完整URL
    "title": string,      // 当前标签页标题
    "audible": boolean,   // 是否在播放音频
    "incognito": boolean, // 是否无痕模式
    "tabCount": number,   // 总标签页数
    "timestamp": string   // ISO 8601
}
```

### 4.4 PIM 客户端 HTTP 端点

```csharp
// BrowserBridgeService
// 在守护程序中启动一个轻量 HttpListener
// 监听 localhost:15601（仅本地访问）

class BrowserBridgeService
{
    HttpListener _listener;
    Channel<BrowserHeartbeat> _heartbeats;  // 发送给 NativeTrackerService

    async Task HandleHeartbeat(HttpListenerContext ctx)
    {
        var heartbeat = await JsonSerializer.DeserializeAsync<BrowserHeartbeat>(ctx.Request.InputStream);
        _heartbeats.Writer.TryWrite(heartbeat);
        // 返回204 No Content
    }
}
```

---

## 5. 服务端设计

### 5.1 新数据表

```sql
CREATE TABLE pc_tracker_events (
    id              BIGSERIAL PRIMARY KEY,
    device_id       VARCHAR(64) NOT NULL,
    timestamp       TIMESTAMPTZ NOT NULL,
    duration        DOUBLE PRECISION NOT NULL DEFAULT 0,
    event_type      VARCHAR(16) NOT NULL,  -- 'window', 'idle', 'gap', 'web-page'
    exe_path        TEXT,                   -- 进程完整路径
    app_name        VARCHAR(256),           -- 标准化后的应用名
    display_name    VARCHAR(256),           -- 显示名称
    window_title    TEXT,                   -- 窗口标题
    command_line    TEXT,                   -- 命令行参数（管理员权限获取）
    is_idle         BOOLEAN DEFAULT FALSE,
    is_media_active BOOLEAN DEFAULT FALSE,  -- 空闲期间是否有媒体播放
    url             TEXT,                   -- 浏览器URL
    domain          VARCHAR(512),           -- 域名
    page_path       TEXT,                   -- URL路径
    audible         BOOLEAN,               -- 是否有音频
    incognito       BOOLEAN,               -- 无痕模式
    tab_count       INTEGER,               -- 标签页数
    page_visit_count INTEGER DEFAULT 0,    -- 合并的短页面访问数
    page_visit_duration DOUBLE PRECISION DEFAULT 0, -- 合并的短页面时长
    raw_json        JSONB,                 -- 原始数据
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    date            DATE NOT NULL           -- 分区键
);

CREATE INDEX idx_tracker_events_device_date ON pc_tracker_events(device_id, date);
CREATE INDEX idx_tracker_events_timestamp ON pc_tracker_events(timestamp);
CREATE INDEX idx_tracker_events_app ON pc_tracker_events(app_name, date);
```

### 5.2 上传接口

```
POST /pc/tracker/upload
Content-Type: application/json
Authorization: Bearer <daemon-token>

{
    "deviceId": "DESKTOP-XXX",
    "events": [
        {
            "timestamp": "2026-08-31T10:00:00Z",
            "duration": 300.5,
            "eventType": "window",
            "exePath": "C:\\...\\chrome.exe",
            "appName": "chrome",
            "displayName": "Google Chrome",
            "windowTitle": "GitHub - ...",
            "commandLine": "\"C:\\...\\chrome.exe\" --profile=Default",
            "isIdle": false,
            "isMediaActive": false,
            "url": null,
            "domain": null,
            "audible": null,
            "pageVisitCount": 0,
            "pageVisitDuration": 0,
            "rawJson": {...},
            "date": "2026-08-31"
        }
    ]
}

Response:
{ "code": 0, "data": 15 }
```

### 5.3 健康状态上报

```
POST /pc/tracker/health
{
    "deviceId": "DESKTOP-XXX",
    "status": "running",
    "uptimeSeconds": 3600,
    "hookActive": true,
    "pollCount": 360,
    "sessionsCreated": 25,
    "eventsUploaded": 500,
    "uploadFailures": 0,
    "lastError": null,
    "browserConnected": true,
    "browserHeartbeatAgeSeconds": 30
}
```

### 5.4 服务端处理层

复用现有的 `BrowserPageTimelineBuilder` 思路，数据源改为 `pc_tracker_events`：

```csharp
// PcTrackerService 中新增
public async Task<int> UploadTrackerEventsAsync(TrackerEventsUploadRequest req, CancellationToken ct)
{
    // 批量插入 pc_tracker_events
    // 复用现有的分类逻辑（ActivityClassifier）
    // 复用现有的平滑逻辑（ActivityTimelineSmoothingService）
}
```

---

## 6. 日志与错误处理

### 6.1 本地日志

```
路径: %LOCALAPPDATA%/PIM/logs/tracker-YYYY-MM-DD.log
格式: [LEVEL] TIMESTAMP [Component] Message
级别: DEBUG / INFO / WARN / ERROR
保留: 30天滚动清理
```

### 6.2 关键日志点

| 组件 | 日志点 | 级别 |
|---|---|---|
| 窗口追踪 | Hook 注册成功/失败/丢失/恢复 | INFO/WARN |
| 窗口追踪 | 每次窗口切换（exe + title） | DEBUG |
| 空闲检测 | 空闲开始/结束（含阈值） | INFO |
| 空闲检测 | 媒体活跃延长空闲阈值 | DEBUG |
| 会话管理 | 会话打开/关闭（含时长） | INFO |
| 会话管理 | Gap 检测（含 gap 时长） | INFO |
| 浏览器桥接 | 插件连接/断开 | INFO |
| 浏览器桥接 | 收到心跳（含 URL） | DEBUG |
| 上传 | 上传成功（含条数） | INFO |
| 上传 | 上传失败（含完整错误） | ERROR |
| 上传 | 重试次数 | WARN |
| 全局 | 任何未捕获异常（含 stack trace） | ERROR |

### 6.3 托盘提示

| 场景 | 提示方式 |
|---|---|
| 追踪器启动失败 | 托盘图标变红 + tooltip 显示原因 |
| 上传连续失败 > 3次 | 托盘气泡 "PC数据上传异常，请检查网络" |
| 浏览器插件断开 > 10分钟 | 托盘气泡 "浏览器追踪已断开，请检查插件" |
| Hook 丢失 | 日志 WARN，自动降级为纯轮询 |

### 6.4 健康状态面板

服务端 `/pc/tracker/health` 数据可在管理面板展示：

```
PC 追踪器状态
├ 运行状态: ✅ 运行中
├ 运行时长: 12小时30分
├ Hook: ✅ 活跃
├ 今日会话: 45 个
├ 上传状态: ✅ 正常 (最后上传: 30秒前)
├ 浏览器插件: ✅ 已连接 (最后心跳: 45秒前)
└ 错误: 无
```

---

## 7. 安装与自启动

### 7.1 安装步骤（沿用 PR159 Inno Setup 框架）

```
用户运行 PIM-Setup-v1.x.x.exe
    │
    ├─ 1. 检查 .NET 8 运行时（没有则引导下载）
    │
    ├─ 2. 关闭正在运行的 PIM 进程
    │
    ├─ 3. 复制文件到 C:\Program Files\PIM\
    │     Pim.Client.App.exe     ← 守护程序（含追踪器，管理员权限）
    │     Pim.Shell.App.exe
    │     KeyStats.exe           ← 子进程，继承管理员权限
    │     ...其他 dll
    │
    ├─ 4. 创建计划任务（仅一个）
    │     \PIM\PIM Daemon → HIGHEST, ONLOGON, delay 10s
    │     （清理旧版 Run 注册表项和旧计划任务）
    │
    ├─ 5. 创建开始菜单快捷方式
    │     PIM 守护程序
    │     PIM Shell
    │     卸载 PIM
    │
    └─ 6. 可选：立即启动守护程序
```

### 7.2 自启动流程

```
用户登录 Windows
    │
    └─ Task Scheduler 触发 \PIM\PIM Daemon (HIGHEST, delay 10s)
        │
        └─ Pim.Client.App.exe 启动（管理员权限）
            │
            ├─ 加载配置 (%LOCALAPPDATA%/PIM/config.json)
            │
            ├─ 启动 NativeTrackerService
            │   ├─ 注册 Win32 Hook
            │   ├─ 启动轮询线程
            │   └─ 开始追踪前台窗口
            │
            ├─ 启动 BrowserBridgeService
            │   └─ 监听 localhost:15601
            │
            ├─ 启动 DaemonHeartbeatReporter
            │
            ├─ 拉起 KeyStats.exe（子进程，继承 HIGHEST）
            │
            └─ 系统托盘图标显示
```

### 7.3 浏览器插件安装

```
用户在 Chrome/Edge/Firefox 中：
    │
    ├─ 打开 chrome://extensions (或 edge://extensions)
    ├─ 开启"开发者模式"
    ├─ 点击"加载已解压的扩展程序"
    ├─ 选择 pim-watcher-web/dist/ 目录
    │
    └─ 插件自动连接 PIM 守护程序 (localhost:15601)
        ├─ 连接成功 → 托盘显示"浏览器追踪: ✅"
        └─ 连接失败 → 托盘显示"浏览器追踪: ❌"
```

### 7.4 文件结构

```
C:\Program Files\PIM\
├── Pim.Client.App.exe            ← 守护程序（HIGHEST，含追踪器）
├── Pim.Shell.App.exe             ← Shell 界面
├── KeyStats.exe                  ← 键鼠统计（子进程，继承权限）
├── Pim.Client.Core.dll           ← 核心库
│   ├── NativeTrackerService
│   ├── BrowserBridgeService
│   └── 其他服务
└── ...其他依赖

%LOCALAPPDATA%\PIM\
├── config.json                   ← 配置文件（原子写入）
├── logs/
│   ├── tracker-2026-08-31.log   ← 追踪日志
│   └── daemon.log               ← 守护程序日志
└── data/
    └── tracker-state.json        ← 追踪器状态（游标等）
```

---

## 8. 测试计划

### 8.1 单元测试

- 窗口切换判定逻辑
- 空闲检测阈值计算
- 媒体活跃判定
- Grace 期扣除计算
- Gap 检测
- 会话切分状态机
- 浏览器数据时间对齐

### 8.2 集成测试

- 守护程序启动 → NativeTrackerService 自动启动
- 浏览器插件 → PIM 客户端 HTTP 通信
- 数据上传 → 服务端接收并存储
- 睡眠/休眠 → Gap 检测正确关闭会话
- 长时间运行（24h+）→ 内存泄漏检测

### 8.3 场景测试

| 场景 | 预期 |
|---|---|
| 正常使用 8 小时 | 会话数合理，空闲时间准确 |
| 看 YouTube 1小时 | 算在 Chrome 时间里，不判空闲 |
| 合盖 2小时 | Gap 检测，这段时间不算任何人 |
| 快速切换应用（每个2秒） | 不漏记，会话数 = 切换次数 |
| 浏览器插件断开重连 | 重连后数据补发 |
| 守护程序重启 | 从断点继续，不丢数据 |
