# 会话状态机

## 状态定义

```
IDLE        : 无会话（刚启动 / Gap 后）
TRACKING    : 正在追踪某个应用
MEDIA_IDLE  : 应用在前台但键鼠空闲（媒体活跃）
INPUT_IDLE  : 应用在前台但键鼠空闲（媒体不活跃）
```

## 状态转移

```
                    ┌──────────────────────────────────────────┐
                    │                                          │
                    ▼                                          │
    ┌─────────┐  AppSwitched   ┌───────────┐                   │
    │  IDLE   │ ─────────────▶ │ TRACKING  │ ◀── IdleEnded ── │
    └─────────┘                └───────────┘                   │
         ▲                         │  │  │                    │
         │ GapDetected             │  │  │                    │
         │                         │  │  └── AppSwitched ─────┤
         │                         │  │      (同exe,标题变化)  │
         │                         │  │                       │
         │                         │  └── PageVisit ──────────┤
         │                         │      (记录页面访问)        │
         │                         │                          │
         │                         ▼                          │
         │              ┌──────────────────┐                  │
         │              │   MEDIA_IDLE     │                  │
         │              │ (audible=true)   │                  │
         │              └────────┬─────────┘                  │
         │                       │                            │
         │              IdleStarted                          │
         │              (grace扣除)                           │
         │                       │                            │
         │                       ▼                            │
         │              ┌──────────────────┐                  │
         └── GapDetected│   INPUT_IDLE     │                  │
                        │ (audible=false)  │ ─── IdleEnded ───┘
                        └──────────────────┘
```

## 转移条件详表

| 当前状态 | 事件 | 条件 | 下一状态 | 动作 |
|---|---|---|---|---|
| IDLE | AppSwitched | - | TRACKING | 开新会话 |
| TRACKING | AppSwitched | exe 变化 | TRACKING | 关旧会话，开新会话 |
| TRACKING | PageVisit | 标题变化 | TRACKING | 记录 page_visit |
| TRACKING | 媒体检测 | audible=true | MEDIA_IDLE | 标记媒体活跃 |
| TRACKING | 媒体检测 | idle > 5min, no audio | INPUT_IDLE | 关会话，开 __IDLE__ 会话 |
| MEDIA_IDLE | 媒体检测 | audible=false | TRACKING | 标记媒体不活跃 |
| MEDIA_IDLE | 媒体检测 | idle > 15min | INPUT_IDLE | 关会话，开 __IDLE__ 会话 |
| INPUT_IDLE | IdleEnded | 键鼠活动 | TRACKING | 关 __IDLE__ 会话，开新会话 |
| 任意 | GapDetected | 间隔 > 60s | IDLE | 在 gap 起点关会话 |
| 任意 | 屏幕灭 | - | INPUT_IDLE | 立即切空闲 |
| 任意 | 系统睡眠 | - | INPUT_IDLE | 立即切空闲 |
