# 接口定义 (API Contract)

## 1. 客户端 → 服务端

### 1.1 上传追踪事件

```
POST /pc/tracker/upload
Authorization: Bearer <daemon-token>
Content-Type: application/json

Request:
{
    "deviceId": string,         // Environment.MachineName
    "events": [                 // 批量上传，最大500条/批
        {
            "timestamp": string,       // ISO 8601 UTC
            "duration": number,        // 秒
            "eventType": string,       // "window" | "idle" | "gap" | "web-page"
            "exePath": string|null,    // 进程完整路径
            "appName": string|null,    // 标准化应用名
            "displayName": string|null,// 显示名
            "windowTitle": string|null,// 窗口标题
            "commandLine": string|null,// 命令行参数（管理员权限获取）
            "isIdle": boolean,         // 是否空闲会话
            "isMediaActive": boolean,  // 空闲期间媒体是否活跃
            "url": string|null,        // 浏览器URL
            "domain": string|null,     // 域名
            "pagePath": string|null,   // URL路径
            "audible": boolean|null,   // 音频播放状态
            "incognito": boolean|null, // 无痕模式
            "tabCount": number|null,   // 标签页数
            "pageVisitCount": number,  // 合并的短页面访问数
            "pageVisitDuration": number,// 合并的短页面时长(秒)
            "rawJson": object|null,    // 原始数据
            "date": string             // "YYYY-MM-DD" 分区键
        }
    ]
}

Response:
{
    "code": 0,                  // 0=成功
    "message": string,          // 错误信息（成功时为空）
    "data": number              // 保存的记录数
}
```

### 1.2 健康状态上报

```
POST /pc/tracker/health
Authorization: Bearer <daemon-token>
Content-Type: application/json

Request:
{
    "deviceId": string,
    "status": string,           // "running" | "degraded" | "error"
    "uptimeSeconds": number,
    "hookActive": boolean,      // Win32 Hook 是否活跃
    "pollCount": number,        // 本次启动后的轮询次数
    "sessionsCreated": number,  // 本次启动后创建的会话数
    "eventsUploaded": number,   // 本次启动后上传的事件数
    "uploadFailures": number,   // 上传失败次数
    "lastError": string|null,   // 最近一次错误信息
    "browserConnected": boolean,// 浏览器插件是否已连接
    "browserHeartbeatAgeSeconds": number|null // 距最后一次心跳的秒数
}

Response:
{
    "code": 0,
    "data": "ok"
}
```

## 2. 浏览器插件 → PIM 客户端

### 2.1 心跳

```
POST http://localhost:15601/browser/heartbeat
Content-Type: application/json

Request:
{
    "url": string,              // 当前标签页完整URL
    "title": string,            // 标签页标题
    "audible": boolean,         // 是否在播放音频
    "incognito": boolean,       // 是否无痕模式
    "tabCount": number,         // 总标签页数
    "timestamp": string         // ISO 8601 UTC
}

Response:
204 No Content
```

### 2.2 连接检测

```
GET http://localhost:15601/browser/ping

Response:
200 OK
{ "status": "ok", "version": "1.0.0" }
```

## 3. 数据库表结构

```sql
CREATE TABLE pc_tracker_events (
    id                  BIGSERIAL PRIMARY KEY,
    device_id           VARCHAR(64) NOT NULL,
    timestamp           TIMESTAMPTZ NOT NULL,
    duration            DOUBLE PRECISION NOT NULL DEFAULT 0,
    event_type          VARCHAR(16) NOT NULL,
    exe_path            TEXT,
    app_name            VARCHAR(256),
    display_name        VARCHAR(256),
    window_title        TEXT,
    command_line        TEXT,
    is_idle             BOOLEAN DEFAULT FALSE,
    is_media_active     BOOLEAN DEFAULT FALSE,
    url                 TEXT,
    domain              VARCHAR(512),
    page_path           TEXT,
    audible             BOOLEAN,
    incognito           BOOLEAN,
    tab_count           INTEGER,
    page_visit_count    INTEGER DEFAULT 0,
    page_visit_duration DOUBLE PRECISION DEFAULT 0,
    raw_json            JSONB,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    date                DATE NOT NULL
);

CREATE INDEX idx_tracker_events_device_date ON pc_tracker_events(device_id, date);
CREATE INDEX idx_tracker_events_timestamp ON pc_tracker_events(timestamp);
CREATE INDEX idx_tracker_events_app ON pc_tracker_events(app_name, date);
```

## 4. 客户端配置项

```json
{
    "tracker": {
        "enabled": true,
        "pollIntervalSeconds": 10,
        "idleThresholdSeconds": 300,
        "gapThresholdSeconds": 60,
        "browserBridgePort": 15601,
        "uploadBatchSize": 500,
        "uploadIntervalSeconds": 30,
        "healthReportIntervalSeconds": 300,
        "logRetentionDays": 30,
        "excludedApps": []
    }
}
```
