# 浏览器插件改造指南

## 来源

Fork `ActivityWatch/aw-watcher-web` (MPL-2.0)
仓库: https://github.com/ActivityWatch/aw-watcher-web

## 改动清单

### 1. 去掉 aw-client 依赖

原代码用 `aw-client` npm 包封装了 AW HTTP API。我们只需要发 HTTP 请求，不需要这个包。

**删除**:
```bash
npm uninstall aw-client
```

**替换 `src/background/client.ts`**:
```typescript
// 原代码
import { AWClient, IEvent } from 'aw-client'
const client = new AWClient('aw-client-web', { testing: config.isDevelopment })

// 新代码：纯 fetch
const PIM_BASE_URL = 'http://localhost:15601'

export async function sendHeartbeat(
    data: HeartbeatData,
    pulsetime: number,
): Promise<boolean> {
    try {
        const resp = await fetch(`${PIM_BASE_URL}/browser/heartbeat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ...data,
                timestamp: new Date().toISOString(),
            }),
        })
        return resp.ok
    } catch (err) {
        console.error('Failed to send heartbeat to PIM:', err)
        return false
    }
}

export async function ping(): Promise<boolean> {
    try {
        const resp = await fetch(`${PIM_BASE_URL}/browser/ping`)
        return resp.ok
    } catch {
        return false
    }
}
```

### 2. 简化 heartbeat.ts

**核心逻辑保留**，去掉 AW 相关的 bucket 概念：

```typescript
// 原代码依赖 AW bucket 和 pulsetime
await sendHeartbeat(client, await getBucketId(), now, data, pulsetime)

// 新代码：直接发心跳
await sendHeartbeat({
    url: decodeURL(url),
    title,
    audible: audible ?? false,
    incognito,
    tabCount,
})
```

### 3. 去掉不需要的功能

| 文件/功能 | 处理 |
|---|---|
| `src/background/client.ts` 中的 `ensureBucket` | 删除 |
| `src/background/client.ts` 中的 `detectHostname` | 删除 |
| `src/background/main.ts` 中的 consent 检测 | 删除 |
| `src/background/main.ts` 中的 hostname 检测 | 删除 |
| `src/storage.ts` 中的 apiKey/hostname/syncStatus | 删除 |
| `src/consent/` 整个目录 | 删除 |
| `src/settings/` | 简化（只保留启用/禁用开关） |

### 4. 修改 manifest.json

```json
{
    "name": "PIM Browser Watcher",
    "description": "Tracks active browser tab for PIM usage analytics",
    "permissions": [
        "tabs",
        "alarms",
        "storage",
        "notifications"
    ],
    "host_permissions": [
        "http://localhost:15601/*"
    ]
}
```

### 5. 添加 PIM 客户端端口检测

启动时先检测 PIM 客户端是否在监听：

```typescript
async function waitForPimClient(maxRetries = 10): Promise<boolean> {
    for (let i = 0; i < maxRetries; i++) {
        if (await ping()) return true
        await new Promise(r => setTimeout(r, 3000))
    }
    return false
}

// main.ts 启动时
const connected = await waitForPimClient()
if (!connected) {
    console.error('PIM client not found on port 15601')
    // 显示通知让用户检查守护程序
}
```

### 6. 构建

```bash
# 安装依赖
npm install

# 开发模式（Chrome）
npm run dev

# 生产构建
npm run build

# 输出目录: dist/
# Chrome: 加载 dist/ 为未打包扩展
# Firefox: dist/ 可直接安装
```

## 数据格式对比

### AW 原格式（发给 AW server）
```json
{
    "bucket_id": "aw-watcher-web-chrome_DESKTOP-XXX",
    "pulsetime": 60,
    "event": {
        "timestamp": "2026-08-31T10:00:00Z",
        "duration": 0,
        "data": {
            "url": "https://github.com/xxx",
            "title": "xxx - GitHub",
            "audible": false,
            "incognito": false,
            "tabCount": 5
        }
    }
}
```

### PIM 新格式（发给 PIM 客户端）
```json
{
    "url": "https://github.com/xxx",
    "title": "xxx - GitHub",
    "audible": false,
    "incognito": false,
    "tabCount": 5,
    "timestamp": "2026-08-31T10:00:00Z"
}
```

简化了：去掉了 bucket、pulsetime、嵌套的 event 结构。
