# AW 代码删除清单

## 客户端删除

| 文件 | 操作 |
|---|---|
| `Pim.Client.Core/Services/AwCollectorService.cs` | 整个文件删除 |
| `Pim.Client.Core/Services/AwBucketSelection.cs` | 整个文件删除 |
| `Pim.Client.Core/Models/AwCollectorModels.cs`（如有） | 整个文件删除 |
| `App.xaml.cs` 中 `AwCollectorService` 的启动/注册 | 删除相关行 |
| `MainShellWindow.xaml.cs` 中 AW 状态显示 | 删除或改为 tracker 状态 |
| `DaemonConfig.cs` 中 AW 相关配置 | 删除 |
| `StatusWindow.xaml.cs` 中 AW 同步按钮/状态 | 删除 |

## 服务端删除

| 文件 | 操作 |
|---|---|
| `/pc/aw/upload-complete` 路由 | 删除 |
| AW 上传相关的 DTO/Request 模型 | 删除 |
| `pc_aw_events` 表 | 数据迁移后删除 |
| `AwEventEntity.cs` | 整个文件删除 |

## 安装器更新

| 改动 | 说明 |
|---|---|
| 移除 `\PIM\PIM KeyStats` 计划任务创建 | KeyStats 改为子进程拉起 |
| `\PIM\PIM Daemon` 权限改为 `HIGHEST` | 整个守护程序管理员权限 |
| 清理旧版 KeyStats 计划任务 | 卸载时一并清理 |
