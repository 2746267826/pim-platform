# 现有 PIM AW 相关代码分析

## 客户端侧

### AwCollectorService.cs
位置: `src/client-windows/Pim.Client.Core/Services/AwCollectorService.cs`

**职责**: 轮询本地 AW server（localhost:5600），获取事件并上传到 PIM 服务端

**核心逻辑**:
- 每 30 秒轮询一次 AW API
- 获取 3 种 bucket 类型的数据：`currentwindow`、`afkstatus`、`web.tab.current`
- 批量上传到 PIM 服务端 `/pc/aw/upload-complete`
- 维护游标状态（每个 bucket 的最后处理 ID）
- 支持 backfill（补录历史数据）

**需要保留的接口**:
- `SyncNowAsync()` - 手动同步
- `BackfillAsync()` - 历史补录

**可以删除的**:
- AW bucket 发现逻辑
- AW API 轮询循环
- 游标状态管理

### AwBucketSelection.cs
位置: `src/client-windows/Pim.Client.Core/Services/AwBucketSelection.cs`

**职责**: 定义支持的 AW bucket 类型

```csharp
SupportedTypes = { "currentwindow", "afkstatus", "web.tab.current" }
```

**结论**: 整个文件可以删除，新方案不需要 bucket 概念

## 服务端侧

### AwEventEntity
位置: `src/modules/Pim.Module.PcTracker/Entities/AwEventEntity.cs`

**表**: `pc_aw_events`

**关键字段**:
- `device_id`, `timestamp`, `duration`
- `event_type` ("window"/"afk"/"web")
- `app_name`, `window_title`
- `afk_status`
- `bucket_id`, `bucket_type`, `bucket_client`
- `data_json` (JSONB，原始数据)

**结论**: 新表 `pc_tracker_events` 结构更精简，去掉了 bucket 相关字段

### BrowserPageTimelineBuilder.cs
位置: `src/modules/Pim.Module.PcTracker/Services/BrowserPageTimelineBuilder.cs`

**职责**: 将 AW 的 web 事件转换为 `PcDetailRecord`

**核心逻辑**:
- 从 `data_json` 中解析 URL、title、domain、audible 等
- 短页面聚类（<5秒的页面访问合并）
- 浏览器窗口事件和 web 事件的关联
- 分类（通过 ActivityClassifier）

**结论**: 核心逻辑可复用，但数据源从 `pc_aw_events` 改为 `pc_tracker_events`

### PcTrackerService.cs
位置: `src/modules/Pim.Module.PcTracker/Services/PcTrackerService.cs`

**相关方法**:
- `UpsertKeystatsAsync()` - 键鼠统计上传（与 AW 无关，保留）
- `UploadAwEventsAsync()` - AW 事件上传（需要新增对应的 tracker 版本）
- `BuildInterpretedAwDetailRecordsAsync()` - AW 数据处理（需要适配新数据源）

## 迁移策略

### 短期（开发期）
- 新旧并存：`AwCollectorService` 保留但禁用，`NativeTrackerService` 启用
- 服务端双表查询

### 中期（稳定后）
- 新版本默认启用 NativeTrackerService
- AwCollectorService 通过配置开关控制

### 长期（30天后）
- 清理 AwCollectorService 代码
- 清理 pc_aw_events 表
- 清理 AW 相关的服务端代码
