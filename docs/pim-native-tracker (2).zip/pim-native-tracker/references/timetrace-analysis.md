# TimeTrace 源码分析参考

## 项目信息

- 仓库: https://github.com/wellorbetter/timetrace
- 技术栈: Rust 核心 + Flutter UI
- 协议: MIT
- 核心代码: `crates/core/src/engine/`

## 关键文件

### monitor.rs - 追踪主循环

核心逻辑：Hook + 轮询双保险

```rust
// Hook 线程：监听前台窗口变化
SetWinEventHook(EVENT_SYSTEM_FOREGROUND, ...)
SetWinEventHook(EVENT_OBJECT_NAMECHANGE, ...)

// 轮询线程：
loop {
    // 1. 检测 Gap（睡眠/休眠）
    if (now - last_poll) > poll_interval * 5 {
        emit GapDetected { gap_start }
        current_app = None
    }

    // 2. 空闲检测
    if idle_detector.is_idle(threshold) && !is_idle {
        emit IdleStarted { grace: threshold }
        current_app = None
    }

    // 3. 前台窗口检测
    let foreground = window_resolver.get_foreground_app()
    if foreground != current_app {
        emit AppSwitched { previous, current }
        current_app = foreground
    }

    sleep(poll_interval)
}
```

**关键设计**：
- Hook 事件触发时立即检查，不等轮询
- 两次检查间有最小间隔（500ms）避免频繁查询
- Hook 线程独立运行，有自己的消息循环

### idle_win32.rs - 空闲检测

```rust
fn idle_duration(&self) -> Duration {
    let (tick, last_input) = Self::capture();
    // GetTickCount() - lastInputInfo.dwTime
    let idle_ms = tick.saturating_sub(last_input);
    Duration::from_millis(idle_ms as u64)
}
```

标准 Win32 API，简单可靠。

### aggregator.rs - 会话聚合

```rust
// 事件 → 会话的映射
match event {
    AppSwitched { current, .. } => {
        if same_exe(current, current_session) {
            // 同exe：记录 page_visit，不拆会话
            start_page(current, timestamp)
        } else {
            // 不同exe：关旧会话，开新会话
            close_session(timestamp)
            open_session(current, timestamp)
        }
    }

    IdleStarted { grace, .. } => {
        // grace 期从上一个应用会话中扣除
        let idle_start = timestamp - grace
        close_session(idle_start)
        open_session(AppInfo::idle(), idle_start)
    }

    IdleEnded { current_app, .. } => {
        close_session(timestamp)
        open_session(current_app, timestamp)
    }

    GapDetected { timestamp } => {
        close_session(timestamp)
        // 不创建新会话
    }
}
```

**关键设计**：
- `__IDLE__` 作为特殊应用名记录空闲会话
- Gap 检测在 gap 起点关闭会话，不创建空闲会话
- Grace 期扣除确保不虚增应用时间

### window_win32.rs - 窗口信息获取

```rust
fn get_foreground_app(&self) -> Option<AppInfo> {
    let hwnd = GetForegroundWindow()
    let pid = GetWindowThreadProcessId(hwnd)
    let exe_path = get_process_path(pid)  // QueryFullProcessImageNameW

    // UWP 特殊处理
    if exe_stem == "applicationframehost" || exe_stem == "shellexperiencehost" {
        if let Some(child_pid) = resolve_child_pid(hwnd, pid) {
            exe_path = get_process_path(child_pid)
        }
    }

    let title = GetWindowTextW(hwnd)
    let display_name = display_name_for(exe_path, title)

    Some(AppInfo::new(exe_path, display_name).with_title(title))
}
```

**关键设计**：
- UWP 应用通过子窗口枚举解析真实进程
- `display_name_for` 做应用名标准化

## 对 PIM 的借鉴价值

| TimeTrace 设计 | PIM 适配 |
|---|---|
| Hook + 轮询双保险 | 直接复用 |
| Gap 检测阈值 = poll × 5 | PIM 用 poll × 6 |
| Grace 期扣除 | 直接复用 |
| __IDLE__ 特殊会话 | 直接复用 |
| UWP 子窗口解析 | 直接复用 |
| page_visit 粒度 | 直接复用 |
| 纯轮询（非Windows平台） | PIM 只做 Windows，不需要 |
