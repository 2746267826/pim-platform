# Windows 端全自动测试脚本需求

## 概述

编写一个 PowerShell 测试脚本 `test-tracker.ps1`，在 Windows 上全自动执行 PIM Native Tracker 的各项测试，输出结构化的测试报告。

脚本由用户在本地 Windows 机器上运行，测试完成后将结果发回给 agent 分析。

## 使用方式

```powershell
.\test-tracker.ps1 -Mode Quick          # 约15分钟，核心功能
.\test-tracker.ps1 -Mode Full           # 约30分钟，所有场景
.\test-tracker.ps1 -Mode Stability      # 24小时，稳定性监控
.\test-tracker.ps1 -Modules "Hook,Idle" # 只测指定模块
```

## 测试模块

### EnvCheck（环境检查，所有模式都运行）

1. **管理员权限检测**：当前 PowerShell 是否以管理员运行
2. **PIM 进程检测**：`Pim.Client.App.exe` 是否在运行，记录 PID 和内存占用
3. **KeyStats 进程检测**：`KeyStats.exe` 是否在运行（子进程模式下应为 PID 继承）
4. **浏览器桥接端口检测**：`localhost:15601` 是否监听
5. **PIM API 检测**：`http://127.0.0.1:5858/health` 是否可达
6. **日志目录检测**：`%LOCALAPPDATA%/PIM/logs/` 是否存在
7. **配置文件检测**：`%LOCALAPPDATA%/PIM/config.json` 是否存在

### Hook（窗口事件 Hook 测试）

1. **Hook 注册检查**：从追踪器日志中搜索 Hook 注册成功记录
2. **Hook 稳定性检查**：从日志中搜索 Hook 丢失/掉线记录
3. **主动切换测试**：
   - 打开记事本 → 最小化 → 关闭
   - 检查日志中是否新增了窗口切换记录
   - 验证 Hook 实时响应能力

### WindowTrack（窗口追踪测试）

1. **exe 路径记录检查**：日志中是否包含进程路径信息
2. **窗口标题记录检查**：日志中是否包含窗口标题
3. **会话切换记录检查**：日志中是否有会话切换事件
4. **多应用快速切换测试**：
   - 快速打开 5 个不同应用（notepad/mspaint/calc/explorer/cmd）
   - 每个停留 1-2 秒后切到下一个
   - 关闭所有测试应用
   - 检查日志中会话切换次数是否 ≥3

### Idle（空闲检测测试，需要等待）

1. **空闲触发测试**：
   - 提示用户不要操作键鼠
   - 等待 `idleThreshold + 30秒`
   - 检查日志中是否出现 `IdleStarted` 记录
2. **空闲会话创建检查**：日志中是否有 `__IDLE__` 会话
3. **Grace 期检查**：日志中是否有 grace 期处理记录
4. **空闲恢复测试**：自动移动鼠标恢复活跃，检查日志中 `IdleEnded` 记录

### MediaActive（媒体活跃测试，需要浏览器插件）

1. **浏览器连接检查**：先验证插件已连接
2. **测试步骤**：
   - 提示用户在浏览器打开有声视频
   - 等待 idleThreshold + 60秒
   - 检查日志中是否**没有**出现 idle 判定（说明媒体检测生效）
3. 如果浏览器未连接，跳过此测试并提示

### Gap（Gap 检测测试，需要手动操作）

1. **测试步骤**：
   - 提示用户合盖/手动睡眠
   - 等待用户唤醒后按 Enter
   - 检查日志中是否有 `GapDetected` 记录
2. 此测试无法完全自动化，需用户配合

### Browser（浏览器插件测试）

1. **端口可达性测试**：`GET localhost:15601/browser/ping` 返回 200
2. **手动心跳测试**：构造一个测试心跳 POST 到 `/browser/heartbeat`，验证返回 204
3. **心跳日志检查**：等待几秒后检查追踪器日志中是否记录了该心跳

### Upload（数据上传测试）

1. **上传成功检查**：日志中是否有上传成功记录
2. **上传失败恢复检查**：如有失败记录，检查是否有后续成功（说明重试生效）
3. **上传条数检查**：从日志中提取已上传的事件数量
4. **服务端健康接口检查**：`GET /pc/tracker/health` 是否可达

### LogCheck（日志完整性检查）

1. **日志文件存在且非空**
2. **日志格式检查**：首行是否符合 `[YYYY-MM-DD HH:mm:ss.fff] [LEVEL]` 格式
3. **关键日志点检查**：是否存在 INFO 级别日志、Hook 日志、会话日志、上传日志
4. **错误统计**：统计 ERROR 和 WARN 数量，ERROR 超过 10 条标为异常
5. **异常堆栈检查**：日志中是否有 Exception/Stacktrace 记录

### Stability（稳定性测试，仅 Stability 模式）

1. **采样频率**：每 15 分钟采样一次，持续 24 小时（共 96 个样本）
2. **采样内容**：
   - PIM 进程 CPU 时间（TotalProcessorTime）
   - 内存占用（WorkingSet64）
   - 句柄数（HandleCount）
   - 线程数
3. **内存泄漏判定**：如果内存增长超过初始值的 10%，标记为疑似泄漏
4. **峰值内存**：记录整个测试期间的峰值内存

## 输出

### 文件结构

```
PIM-Test-Results/               ← 默认在桌面
├── test-summary.json           ← JSON 格式结果（agent 分析用）
├── test-report.txt             ← 可读的文本报告（用户查看用）
├── test-execution-YYYYMMDD_HHMMSS.log  ← 脚本执行日志
└── perf-samples/               ← 稳定性测试的采样数据（仅 Stability 模式）
    ├── sample-0001.json
    └── ...
```

### test-report.txt 格式

```
==========================================
  PIM Native Tracker 测试报告
==========================================

模式: Full
时间: 2026-08-31 14:00:00 ~ 14:32:15
耗时: 00:32:15

结果: 18/20 通过 (90%)

------------------------------------------

[EnvCheck]
  ✅ AdminPrivilege: 管理员权限
  ✅ PimProcessRunning: PID: 12345, 内存: 85.2MB

[Hook]
  ✅ HookRegistered: Hook 注册成功
  ❌ WindowSwitchDetected: 切换窗口后新增0行日志

...

------------------------------------------

⚠️  2 项测试失败，请检查上述详情
```

### test-summary.json 格式

```json
{
  "mode": "Full",
  "startTime": "2026-08-31 14:00:00",
  "endTime": "2026-08-31 14:32:15",
  "duration": "00:32:15",
  "total": 20,
  "passed": 18,
  "failed": 2,
  "passRate": 90.0,
  "results": [
    {
      "module": "EnvCheck",
      "test": "AdminPrivilege",
      "passed": true,
      "message": "管理员权限",
      "time": "2026-08-31 14:00:01"
    }
  ]
}
```

## 技术要求

- 纯 PowerShell 实现，不依赖第三方模块
- 兼容 Windows 10/11
- 需要管理员权限运行（用于检查进程信息）
- Win32 API 调用通过 P/Invoke 内联定义（Add-Type）
- 自动创建输出目录
- 每个测试模块独立函数，支持按模块筛选执行
- 测试失败不中断，继续执行后续测试
